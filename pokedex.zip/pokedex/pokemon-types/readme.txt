﻿=== Pokemon Types Icon Set ===

By: Bobcat (http://www.rw-designer.com/user/90502) remus.serediuc@gmail.com

Download: http://www.rw-designer.com/icon-set/pokemon-types

Author's description:

I love pokemon, so I decided to make another icon set with the types! They can be used not only for pokemon sites and projects, but can also be used for descriptive icons. For example, you can use the dark  type one in a website about the moon and stars. I also invented a few types, but they will be easy to spot because of the low quality. Anyways, can you spot them?

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.