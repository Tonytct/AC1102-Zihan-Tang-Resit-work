'use strict';
(function() {
  const BaseUrl = 'https://pokeapi.co/api/v2/pokemon/';

  let selectedPokemon = null;

  const GENS = {
    '1': {
      name: 'kanto',
      pokeDex: [1, 151],
    },
    '2': {
      name: 'johto',
      pokeDex: [152, 251],
    },
    '3': {
      name: 'hoenn',
      pokeDex: [252, 386],
    },
    '4': {
      name: 'sinnoh',
      pokeDex: [387, 493],
    },
    '5': {
      name: 'unova',
      pokeDex: [494, 649],
    },
    '6': {
      name: 'kalos',
      pokeDex: [650, 721],
    },
    '7': {
      name: 'alola',
      pokeDex: [722, 809],
    },
    '8': {
      name: 'galar',
      pokeDex: [810, 890],
    },
  }

  window.addEventListener('load', init);

  /**
   * A init function that intialize the pokedex and. 
   * call api to get the pokemon data.
   */
  function init() {
    fetchPokemon(151, 0).then(renderPokeDex)
    id('gens').innerHTML = renderGens();
    id('gens').addEventListener('change', changeGen);
    qs('#found').addEventListener('click', found);
    qs('#not-found').addEventListener('click', notFound);
    id('search-btn').addEventListener('click', search);
    qs('.modal-close').addEventListener('click', closeModal);
  }

  /**
   * hide the modal
   */
  function closeModal() {
    qs('.modal').classList.add('hidden');
  }

  /**
   * show the modal and display the details of the pokemon and moves it can learn
   * @param {Object} pokemon - The pokemon object 
   */
  function showModal(pokemon) {
    console.log(pokemon);
    let text = capitalize(pokemon.name) + ' appeared in following generations: ';
    text += pokemon.game_indices.map((game) => {
      return game.version.name;
    }).join(', ') || 'Unknown';
    qs('.pokemon-details').textContent = text;
    let moves = pokemon.moves.map((move) => {
      return `<li>${capitalize(move.move.name)}</li>`;
    })
    qs('.pokemon-moves').innerHTML = moves.join('');
    qs('.modal').classList.remove('hidden');
  }

  /**
   * search the pokemon by name and render the result.
   */
  function search() {
    const search = id('search').value;
    if (search.length > 0) {
      fetchPokemon(890, 0).then((data) => {
        const pokemons = data.filter(pokemon => pokemon.name.toLowerCase().includes(search));
        renderPokeDex(pokemons);
      });
    }
  }

  function renderGens() {
    let html = '';
    for (let gen in GENS) {
      html += `<option value="${gen}">GEN ${gen} ${GENS[gen].name} area</option>`;
    }
    return html;
  }

  /**
   * called when the user select a gen from a selector.
   * it will fetch the pokemon data from the api and render the pokedex.
   * @param {*} e the event object
   */
  function changeGen(e) {
    const gen = e.target.value;
    let limit = GENS[gen].pokeDex[1];
    let offset = GENS[gen].pokeDex[0] - 1;
    fetchPokemon(limit - offset, offset).then(renderPokeDex)
  }

  /**
   * mark this pokemon as found.
   * save the pokemon data to local storage.
   * change the color of the found pokemon in the pokedex.
   * and hide the found button and show the not found button.
   */
  function found() {
    let founds = localStorage.getItem('founds');
    if (founds) {
      founds = JSON.parse(founds);
      founds.push(selectedPokemon);
    } else {
      founds = [selectedPokemon];
    }
    id(selectedPokemon).classList.add('found');
    localStorage.setItem('founds', JSON.stringify(founds));
    id('not-found').classList.remove('hidden');
    id('found').classList.add('hidden');
  }

  /**
   * remove this pokemon from the found list.
   * save the pokemon data to local storage.
   * change the color of the not found pokemon in the pokedex to dark.
   * and hide the not found button and show the found button.
   */
  function notFound() {
    let founds = localStorage.getItem('founds');
    if (founds) {
      founds = JSON.parse(founds);
      founds = founds.filter(pokemon => pokemon.name !== selectedPokemon.name);
    }
    localStorage.setItem('founds', JSON.stringify(founds));
    id(selectedPokemon).classList.remove('found');
    id('found').classList.remove('hidden');
    id('not-found').classList.add('hidden');
  }

  /**
   * call api to get the pokemon data.
   * and map the data to the object that we need.
   * 
   * @param {Number} limit how many pokemon to fetch
   * @param {Number} offset the start index of the pokemon
   * @returns 
   */
  function fetchPokemon(limit, offset) {
    return fetch(BaseUrl + `?limit=${limit}&offset=${offset}`)
      .then(res => res.json())
      .then(data => {
        let pokemons = data.results;

        return pokemons.map(pokemon => {
          let id = pokemon.url.split('/')[6];
          return {
            name: pokemon.name,
            img: `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`
          }
        })
      })
  }

  /**
   * Add pokemon images to pokedex view and add click event to found pokemon
   * @param {Array} data a array of pokemon object
   */
  function renderPokeDex(pokemons) {
    id('pokedex-view').innerHTML = '';
    for (let pokemon of pokemons) {
      let img = create('img');
      let name = pokemon.name;
      img.src = pokemon.img;
      img.alt = name;
      img.id = name;

      img.classList.add('sprite');

      let founds = localStorage.getItem('founds');
      if (founds) {
        founds = JSON.parse(founds);
        if (founds.includes(name)) {
          img.classList.add('found');
        }
      }
      img.title = capitalize(name);
      img.addEventListener('click', function() { getPokemon(img.id) })
      id('pokedex-view').appendChild(img);

    }
  }

  /**
   * make a fetch request to get pokemon detail and update pokemon card
   * @param {string} name the name of pokemon
   */
  async function getPokemon(name) {
    id('not-found').classList.add('hidden')
    id('found').classList.add('hidden')
    let data = await fetch(BaseUrl + name)
    data = await data.json();
    renderPokemon(data);
    let founds = localStorage.getItem('founds');
    if (founds && founds.includes(name)) {
      id('not-found').classList.remove('hidden');
    } else {
      id('found').classList.remove('hidden');
    }
    qs('.more').addEventListener('click', () => showModal(data));
    selectedPokemon = name;
  }


  /**
   * capitalize the first letter of the string
   * @param {String} s 
   * @returns the string with the first letter capitalized
   */
  function capitalize(s) {
    return s[0].toUpperCase() + s.slice(1);
  }

  /**
   * Update pokemon name, image, stats and types in the card
   * 
   * @param {Object} pokemon a object of a pokemon
   */
  function renderPokemon(pokemon) {
    let types = pokemon.types.map(type => type.type.name);
    qs(`#pokemon .name`).textContent = pokemon.name.toUpperCase();
    qs(`#pokemon .pokepic`).src = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pokemon.id}.png`
    qs(`#pokemon #types`).innerHTML = types.map(type => `<img src="pokemon-types/${capitalize(type)} type.ico" />`).join('');
    let stats = pokemon.stats.map(stat => {
      return {
        base_stat: stat.base_stat,
        stat_name: stat.stat.name
      }
    });
    let div = id(`infos`);

    div.innerHTML = stats.map(stat => {
      return `<table>
      <thead>
        <tr>
          <th>${capitalize(stat.stat_name)}</th>
          <th>${stat.base_stat}</th>
        </tr>
      </thead>
     </table>`
    }).join('')
  }

  /**
   * Just function to get the element by id
   * @param {String} id the id of the element
   * @returns {Element} the element
   */
  function id(id) {
    return document.getElementById(id);
  }

  /**
   * an function to quickly select element by using querySelector.
   * @param {String} query a query selector
   * @returns {Element} Return elements match the query.
   */
  function qs(query) {
    return document.querySelector(query);
  }

  /**
   * an short-cut function to quickly create element.
   * @param {String} tagName The tag name of the element
   * @returns {Element} Return the created element node.
   */
  function create(tagName) {
    return document.createElement(tagName);
  }

})();