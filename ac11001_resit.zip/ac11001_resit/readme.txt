 1. Describe what you understand by the word “class” in a software development context?
class is like a blueprint of a object for the real world. it defined the properties of the object and what
action can be performed on the object. such as dog, when can define a class named Dog and define the how many legs it has, 
what color it is, what kind of dog it is etc.

 2. When is it NOT necessary to use curly braces after an if or else if test?
when there is only one statment after the if or else if test, it is not necessary to use curly braces.

 3. Why is the main method always defined as a static method?
beacuse the main method need to be called before the creation of an object of the class. 
Therefore, the main method must be defined as static .

 4. Why do you think this use of dummy methods is common in software
development?
because it is used to test the functionality of the program.



 5. In addition to using tabs, how could you format the numbers so that they appeared in a neat table? (Note that you do not have to code this unless you want to!)
use System.out.printf(format, arguments) to format the float number.  

 6. What is the difference between a binary file and a text file in the Windows operating system?
Binary file only store data with 0 and 1 that represent a custom data.
A text file store data as human-readable characters.

 7. Why do you think it is important in real life to incorporate features such as those suggested above to improve usability?
In real life, an action includes multiple steps normally, 
those incorporated features above are the steps to complete the operation for choice3(). 
Therefore, we can define one action that contains mutilple steps and use the action instead telling people what steps you need to do. 

8. Comment on the coupling of the classes you have developed in this test?
Yes

9. Comment on the cohesion of the classes you have developed in this test?
Yes

 10. Why is it important to gather requirements and carry out a preliminary design before starting to code software?
Preliminary designs can improve Software Development by giving you a mature plan, 
preventing mistakes, identifying and avoid risks.