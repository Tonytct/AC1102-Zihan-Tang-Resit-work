/**
 * 
 */
package test_resit;
import java.util.Scanner;

/**
 * @author1
 *
 */
public class Menu {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        Exercises exercises = new Exercises();

        while (true) {

            // presents the user with a menu from which they can choose THREE options
            System.out.println("Please choose an option: \n 1. for loop \n 2. file write \n 3. file read\n");
            // asks the user to enter their choice
            int choice;

            while (scanner.hasNext() && !scanner.hasNextInt()) {
                System.out.print(scanner);
                String input = scanner.next();

                System.out.printf("\"%s\" is not a valid number.%n", input);
            }
            choice = scanner.nextInt();
            System.out.println("You chose " + choice);
            if (choice == 1) {
                System.out.println("Enter a number: ");
                // keep asking the user to enter a number until they enter a valid number
                int n;
                while (!scanner.hasNextInt()) {
                    String input = scanner.next();
                    System.out.printf("\"%s\" is not a valid number.%n", input);
                }
                n = scanner.nextInt();

                exercises.choice1(n);
            } else if (choice == 2) {
                exercises.choice2();
            } else if (choice == 3) {
                exercises.choice3();
            } else {
                System.out.println("Invalid choice");
            }
        }
    }

}
