/**
 * 
 */
package test_resit;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * @author
 *
 */
public class Exercises {

	public void choice1(int n) {
		// display message "For loop exercise:"
		// display all values between 0 and maximum, the square of the values and the
		// cube of the values
		System.out.println("Value\tSquare\tCube");
		for (int i = n; i >= 1; i--) {
			System.out.printf("%.2f\t%.2f\t%.2f\n", (float) i, (float) (i * i), (float) (i * i * i));
		}
	}

	public void choice2() {
		// display message "File write exercise:"

		int[] numbers = new int[6];
		for (int i = 0; i < numbers.length; i++) {
			System.out.println("Enter number " + (i + 1) + ": ");
			// int n;
			while (!Menu.scanner.hasNextInt()) {
				String input = Menu.scanner.next();
				System.out.printf("\"%s\" is not a valid number.%n", input);
			}
			// n = scanner.nextInt();
			numbers[i] = Menu.scanner.nextInt();
		}
		// Calculate the average of the six numbers.
		float sum = 0;
		for (int i = 0; i < numbers.length; i++) {
			sum += numbers[i];
		}
		float average = sum / numbers.length;
		// System.out.println("The average of the six numbers is: " + average);

		// write the six numbers to the file.
		try {
			FileWriter writer = new FileWriter("numbers.txt");
			for (int i = 0; i < numbers.length; i++) {
				writer.write(numbers[i] + "\n");
			}
			// Write the average value to file too (as a float).
			writer.write(average + "\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println('\n' + "The numbers have been written to numbers.txt.");
		System.out.println();

	}

	/**
	 * 	
	 * 
	 */
	public void choice3() {
		// display message "File read exercise:"
		int[] numbers = new int[6];
		try {
			Scanner scanner = new Scanner(new java.io.File("numbers.txt"));

			// store the six numbers from the file (revserse order)
			for (int i = numbers.length - 1; i >= 0; i--) {
				numbers[i] = scanner.nextInt();
			}

			System.out.println("The six numbers are (revserse order): ");
			// Print the numbers.
			for (int i = 0; i < numbers.length; i++) {
				System.out.print(numbers[i] + ", ");
			}

			System.out.println();
			// Read in and print the average too
			float average = scanner.nextFloat();
			System.out.println("The average of the six numbers is: " + average);
			System.out.println();
		} catch (Exception e) {
			// TODO: handle exception

		}
	}
}